<?php
$conn = mysqli_connect("localhost", "root", "", "building_management");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Query to retrieve data from the 'login' table
$sql = "SELECT * FROM issue_details";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Issue Details</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
            color: #333;
        }

        header {
            background-color: #333;
            color: white;
            padding: 10px;
            text-align: center;
        }

        nav {
            background-color: #3333;
            color: white;
            text-align: center;
            padding: 5px;
            height: 35px;
        }

        nav a {
            text-decoration: none;
            color: black;
            font-size: 15px;
            margin: 0 20px; /* Adjust margin as needed */
        }
        .search-bar {
    width: 100%;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: flex-end; /* Push the search bar to the right */
}


        .search-icon {
            font-size: 20px;
            margin-right: 10px;
            color: #333;
        }

        .search-input {
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            width: 200px;
            outline: none;
        }

        .search-input::placeholder {
            color: #999;
        }

        .employee-table {
            margin-top: 20px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .employee-table h3 {
            margin-top: 0;
        }

        .employee-table table {
            width: 100%;
            border-collapse: collapse;
        }

        .employee-table th,
        .employee-table td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: center;
        }

        .employee-table th {
            background-color: #f2f2f2;
        }
    </style>
</head>

<header>
        
        <center>
            
        <h1>Smart Building  
        </h1></center>
    </header>

<body>
    

    <nav>
        <a href="manager.php">Home</a>
       <a href="viewstaff.php">Asigned Work</a>
                <a href="jobhistory.php">Status</a>
                <a href="managerprofile.php">Profile</a>
                <a href="login.php">Logout</a>
    </nav>

    <main>
    <div class="search-bar">
            <span class="search-icon">&#128269;</span>
            <input type="text" id="search-input" class="search-input" placeholder="Search..." oninput="searchTable()">
        </div>
        <div class="employee-table">
            <h3>Issue Details</h3>
            <table>
                <thead>
                    <tr>
                        <th>Sl.No</th>
                        <th>Worker Name</th>
                        <th>User Name</th>
                        <th>Block</th>
                        <th>Door No</th>
                        <th>Issue</th>
                        <th>Repeated</th>
                      
                        <th>Mobile</th>
                        <th>Type of Issue</th>
                        <th>Reporting On</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Loop through the data retrieved from the database -->
                    <?php
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['worker_name'] . "</td>";
                        echo "<td>" . $row['user_name'] . "</td>";
                        echo "<td>" . $row['block'] . "</td>";
                        echo "<td>" . $row['door'] . "</td>";
                        echo "<td>" . $row['issue'] . "</td>";
                        echo "<td>" . $row['repeated'] . "</td>";
                    
                        echo "<td>" . $row['mob_num'] . "</td>";
                        echo "<td>" . $row['issues'] . "</td>";
                        echo "<td>" . $row['dateofreporting'] . "</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </main>

    <footer>
        <!-- Your footer content goes here -->
    </footer>
</body>

</html>
