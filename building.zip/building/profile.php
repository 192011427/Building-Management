<?php
include 'dbconfig.php';

$username = $_GET['username'];

$loginqry = "SELECT * FROM login WHERE username = '$username'";
$qry = mysqli_query($dbconn, $loginqry);

$response = array();

if (mysqli_num_rows($qry) > 0) {
    $userArray = array();
    while ($userObj = mysqli_fetch_assoc($qry)) {
        $userArray[] = $userObj;
    }
    $response['status'] = true;
    $response['message'] = "Login Successfully";
    $response['data'] = $userArray;
} else {
    $response['status'] = false;
    $response['message'] = "Login Failed";
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
