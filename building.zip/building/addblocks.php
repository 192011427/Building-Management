<?php
require_once('dbconfig.php'); // Assuming this file contains your database connection logic

$id = $_POST['id'];
$block = $_POST['block'];
$floor = $_POST['floor'];
$blockname = $_POST['blockname'];
$parking = $_POST['parking'];

$response = array();

if (empty($id) || empty($block) || empty($floor) || empty($blockname) || empty($parking)) {
    $response['status'] = false;
    $response['message'] = "All fields are required.";
} else {
    // Check if the user already exists
    $userExistQuery = "SELECT * FROM add_block WHERE id = '$id'";
    $userExistResult = mysqli_query($dbconn, $userExistQuery);

    if (mysqli_num_rows($userExistResult) == 0) {
        // User does not exist, proceed with registration
        $insertData = "INSERT INTO add_block(id, block, floor, blockname, parking) 
                       VALUES ('$id', '$block', '$floor', '$blockname', '$parking')";
        $qry = mysqli_query($dbconn, $insertData);

        if ($qry) {
            $id = mysqli_insert_id($dbconn);
            $response['status'] = true;
            $response['message'] = "Registered Successfully";
        } else {
            $response['status'] = false;
            $response['message'] = "Registration Failed";
        }
    } else {
        $response['status'] = false;
        $response['message'] = "User with id $id already exists.";
    }
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
