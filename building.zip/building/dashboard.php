<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: white;
        }

        header {
            background-color: #333;
            color: white;
            padding: 10px;
            text-align: center;
        }

        nav {
            background-color: #4444;
            color: white;
            padding: 1px;
            text-align: center;
        }

        ul {
            list-style: none;
            padding: 0;
        }

        li {
            display: inline;
            margin-right: 10px;
        }

        a {
            text-decoration: none;
            color: black;
        }

        main {
            padding: 10px;
        }

        section {
  margin: 30px auto; /* Set top and bottom margin to 30px and left and right margin to auto */
  width: 70%;
  padding: 20px;
  border: 1px solid #ddd;
  background-color: white;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}


        section h2 {
            text-align: center;
        }

        h2 {
            margin-top: 0;
        }

        /* Additional styling for the dropdown */
        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropbtn {
            /* Remove background color and border */
            background-color: transparent;
            border: none;
            color: black;
            font-size: 16px;
            text-align: center;
            cursor: pointer;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            z-index: 1;
        }

        .dropdown-content a {
            padding: 10px 16px;
            display: block;
            text-decoration: none;
            color: #333;
        }

        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dropdown:hover .dropbtn {
            color: #333;
        }
    </style>
</head>
<body>
    <header>
        <h1>SmartBuilding 
        </h1>
    </header>

    <nav>
        <ul>
            
            <li>
                <!-- Dropdown for "Add" -->
                <div class="dropdown">
                    <button class="dropbtn">Add</button>
                    <div class="dropdown-content">
                    <a href="addemployee.php"> Employee</a>
                        <a href="addevent.php">Event</a>
                        <a href="addann.php">Announcement</a>
                        <a href="addcontact.php">Emergency Contacts</a>
                        <a href="addparking.php">Parking</a>
                        <a href="addblock.php">Buildings</a>
                    </div>
                </div>
            </li>
          
            <li>
                <a href="emp.php">Employee Details</a>
            </li>
            <li>
                <a href="profile.php">My Profile</a>
            </li>
            <li>
                <a href="login.php">Logout</a>
            </li>
        </ul>
    </nav>

    <main>
        <section id="facade">
            <h2><a href="facade.php">Buildings</a></h2>
        </section>
        <section id="residents">
            <h2><a href="resident.php">Residents</a></h2>
        </section>

        <section id="parking">
            <h2><a href="parking.php">Parking Area</a></h2>
        </section>
        <section id="Complaints">
            <h2><a href="admincomplaints.php">Complaints</a></h2>
        </section>

        <section id="security">
            <h2><a href="security.php">Security Features</a></h2>
        </section>

       
       
        
    </main>
</body>
</html>
