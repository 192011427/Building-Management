<?php
require_once('dbconfig.php');

$user_id = $_POST['user_id'];
$name = $_POST['name'];
$username = $_POST['username'];
$password = $_POST['password'];
$role = $_POST['role'];
$assignblock = $_POST['assignblock'];
$mobno = $_POST['mobno'];
$dob = $_POST['dob'];

$response = array();

if (empty($user_id) || empty($name) || empty($username) || empty($password) || empty($role) || empty($assignblock) || empty($mobno) || empty($dob)) {
    $response['status'] = false;
    $response['message'] = "All fields are required.";
} else {
    // Check if the user already exists by user_id (assuming user_id is a unique identifier)
    $userExistQuery = "SELECT * FROM login WHERE user_id = '$user_id'";
    $userExistResult = mysqli_query($dbconn, $userExistQuery);

    if (mysqli_num_rows($userExistResult) == 0) {
        $insertData = "INSERT INTO login(user_id, name, username, password, role, assignblock, mobno, dob) 
                       VALUES ('$user_id', '$name', '$username', '$password', '$role', '$assignblock', '$mobno', '$dob')";
        $qry = mysqli_query($dbconn, $insertData);

        if ($qry) {
            $id = mysqli_insert_id($dbconn);
            $response['status'] = true;
            $response['message'] = "Registered Successfully";
            $response['UserId'] = $user_id;
        } else {
            $response['status'] = false;
            $response['message'] = "Registration Failed";
        }
    } else {
        $response['status'] = false;
        $response['message'] = "User with user_id $user_id already exists.";
    }
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
