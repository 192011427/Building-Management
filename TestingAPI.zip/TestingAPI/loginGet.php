<?php error_reporting(0); ?> 
<?php
require_once('dbconfig.php');

$username = "";
$password = "";

$bioid=$_GET['username'];
$password=$_GET['password'];

$loginqry = "SELECT * FROM login WHERE username = '$username' AND password = '$password'";

$qry = mysqli_query($dbconn, $loginqry);

if(mysqli_num_rows($qry) > 0){
	
	$userObj = mysqli_fetch_assoc($qry); //
	$response['status'] = true;
	$response['message']= "Login Successfully";
	$response['data'] = $userObj;	
}
else{
	$response['status'] = false;
	$response['message']= "Login Failed";	
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>


