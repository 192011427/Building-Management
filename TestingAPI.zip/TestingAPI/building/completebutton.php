<?php
// Set the appropriate content type for JSON
header('Content-Type: application/json');

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Establish a database connection
    $conn = mysqli_connect("localhost", "root", "", "building_management");

    if (!$conn) {
        // If the connection fails, return an error response
        echo json_encode(['status' => false, 'message' => 'Database connection failed']);
    } else {
        // Retrieve and sanitize data from the POST request
        $id = $_GET['id'];

        // SQL query to update the issue status in the database
        $sql = "UPDATE issue_details SET status = 'completed' WHERE id = '$id' ";

        // Execute the query
        if (mysqli_query($conn, $sql)) {
            // If the update is successful, return a success response with status true
            echo json_encode(['status' => true, 'message' => 'Issue Closed successfully']);
        } else {
            // If there's an error with the query, return an error response with status false
            echo json_encode(['status' => false, 'message' => 'Failed to Close Issue']);
        }

        // Close the database connection
        mysqli_close($conn);
    }
} else {
    // If the request method is not POST, return a message indicating the invalid request method with status false
    echo json_encode(['status' => false, 'message' => 'Invalid request method']);
}
?>