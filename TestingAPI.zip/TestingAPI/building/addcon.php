<?php
require_once('dbconfig.php');

$ID = $_POST['ID'];
$type = $_POST['type'];
$mobno = $_POST['mobno'];



$response = array();

if (empty($ID) || empty($type) || empty($mobno)  ) {
    $response['status'] = false;
    $response['message'] = "All fields are required.";
} else {
    // Check if the user already exists by user_id (assuming user_id is a unique identifier)
    $userExistQuery = "SELECT * FROM contacts WHERE ID = '$ID'";
    $userExistResult = mysqli_query($dbconn, $userExistQuery);

    if (mysqli_num_rows($userExistResult) == 0) {
        $insertData = "INSERT INTO contacts(ID,type,mobno) 
                       VALUES ('$ID', '$type', '$mobno')";
        $qry = mysqli_query($dbconn, $insertData);

        if ($qry) {
            $id = mysqli_insert_id($dbconn);
            $response['status'] = true;
            $response['message'] = "Registered Successfully";
            $response['UserId'] = $ID;
        } else {
            $response['status'] = false;
            $response['message'] = "Registration Failed";
        }
    } else {
        $response['status'] = false;
        $response['message'] = "User with user_id $ID already exists.";
    }
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
