<?php
include 'dbconfig.php';
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Include necessary files or establish a database connection here if needed.

    $response = array();

    // Check if the required fields are provided in the POST request
    if (isset($_POST['id'])) {
        $vidid = $_POST['id'];

        // Replace this with your database insert logic
        // Example:
        $sql = "DELETE FROM add_block WHERE id=$vidid";
        $qry = mysqli_query($dbconn, $sql);

        // Check if the query was successful
        if ($qry) {
            $response['status'] = true;
            $response['message'] = "Employee deleted successfully.";
        } else {
            $response['error'] = "Error deleting employee: " . mysqli_error($dbconn);
        }
    } else {
        $response['error'] = "Missing required fields.";
    }
} else {
    $response['error'] = "Invalid request method.";
}

echo json_encode($response);
