<?php
require_once('dbconfig.php');

$c_id = $_POST['c_id'];
$name = $_POST['name'];
$doorno = $_POST['doorno'];
$issue_type = $_POST['issue_type'];
$repeated = $_POST['repeated'];
$mobno = $_POST['mobno'];
$issue = $_POST['issue'];
$status = $_POST['status'];
$response = array();

if (empty($c_id) || empty($name) ||  empty($doorno) || empty($issue_type) || empty($repeated) ||  empty($mobno) || empty($issue)  || empty($status)  ) {
    $response['status'] = false;
    $response['message'] = "All fields are required.";
} else {
    // Check if the user already exists by user_id (assuming user_id is a unique identifier)
    $userExistQuery = "SELECT * FROM complaints WHERE c_id = '$c_id'";
    $userExistResult = mysqli_query($dbconn, $userExistQuery);

    if (mysqli_num_rows($userExistResult) == 0) {
        $insertData = "INSERT INTO complaints(c_id,name,doorno,issue_type,repeated,mobno,issue,status) 
                       VALUES ('$c_id', '$name', '$doorno','$issue_type','$repeated','$mobno','$issue','$status')";
        $qry = mysqli_query($dbconn, $insertData);

        if ($qry) {
            $id = mysqli_insert_id($dbconn);
            $response['status'] = true;
            $response['message'] = "Registered Successfully";
            $response['UserId'] = $c_id;
        } else {
            $response['status'] = false;
            $response['message'] = "Registration Failed";
        }
    } else {
        $response['status'] = false;
        $response['message'] = "User with user_id $c_id already exists.";
    }
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>

