<?php error_reporting(0); ?> 
<?php
require_once('dbconfig.php');

//$bioid = "";
//$password = "";

//$bioid=$_GET['bioid'];
//$password=$_GET['password'];

$loginqry = "SELECT * FROM issue_details";

$qry = mysqli_query($dbconn, $loginqry);

if(mysqli_num_rows($qry) > 0){
	
	$i =0;
	while($row = mysqli_fetch_assoc($qry)){
	$student[$i]['id'] = $row['id'];
	$student[$i]['worker_name'] = $row['worker_name'];
	$student[$i]['user_name'] = $row['user_name'];
	$student[$i]['block'] = $row['block'];
	$student[$i]['door'] = $row['door'];
	$student[$i]['issue'] = $row['issue'];
	$student[$i]['repeated'] = $row['repeated'];
	$student[$i]['mob_num'] = $row['mob_num'];
	$student[$i]['issues'] = $row['issues'];
	$student[$i]['dateofreporting'] = $row['dateofreporting'];
	
	
	$i = $i+1;
	}
	//$userObj = mysqli_fetch_assoc($qry);
	$response['status'] = true;
	$response['message']= "Login Successfully";
	$response['data'] = $student;	
}
else{
	$response['status'] = false;
	$response['message']= "No Data";	
}
header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>