<?php
include 'dbconfig.php';

$response = array();

if (isset($_GET['username'])) {
    $username = $_GET['username'];

    $loginqry = "SELECT name, role,dob, mobno FROM login WHERE username = '$username'";
    $qry = mysqli_query($dbconn, $loginqry);

    if ($qry) {
        if (mysqli_num_rows($qry) > 0) {
            $userObj = mysqli_fetch_assoc($qry);
            $response['status'] = true;
            $response['message'] = "Login Successfully";
            $response['data'] = $userObj;
        } else {
            $response['status'] = false;
            $response['message'] = "Login Failed";
        }
    } else {
        $response['status'] = false;
        $response['message'] = "Database query failed";
    }
} else {
    $response['status'] = false;
    $response['message'] = "Username not provided";
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
