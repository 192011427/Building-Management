<?php
error_reporting(0);
require_once('dbconfig.php');

$id = $_GET['user_id'];

$loginqry = "SELECT * FROM issue_details WHERE status='pending' ";

$qry = mysqli_query($dbconn, $loginqry);

$response = array();

if (mysqli_num_rows($qry) > 0) {
    $i = 0;
    while ($row = mysqli_fetch_assoc($qry)) {
        $student[$i]['id'] = $row['id'];
        $student[$i]['worker_name'] = $row['worker_name'];
        $student[$i]['user_name'] = $row['user_name'];
		$student[$i]['issue'] = $row['issue'];
        $student[$i]['door'] = $row['door'];
        $i = $i + 1;
    }
    $response['status'] = true;
    $response['message'] = "Data retrieved successfully";
    $response['data'] = $student;
} else {
    $response['status'] = false;
    $response['message'] = "No Data";
    $response['data'] = [];
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
