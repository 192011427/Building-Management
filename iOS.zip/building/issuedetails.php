<?php
include 'dbconfig.php'; // Include your database configuration

// Check if 'c_id' is set in the GET request
if (isset($_GET['c_id'])) {
    $c_id = $_GET['c_id'];

    // Create and execute the SQL query to retrieve data based on 'c_id'
    $loginqry = "SELECT * FROM complaints WHERE c_id = '$c_id'";
    $qry = mysqli_query($dbconn, $loginqry);

    // Initialize the response array
    $response = array();

    if ($qry) {
        if (mysqli_num_rows($qry) > 0) {
            $data = array(); // Initialize an array to hold the data
            while ($row = mysqli_fetch_assoc($qry)) {
                $data[] = $row; // Add each row to the data array
            }

            $response['status'] = true;
            $response['message'] = "Data Retrieved Successfully";
            $response['data'] = $data; // Store the data array in the response
        } else {
            $response['status'] = false;
            $response['message'] = "No Data Found";
        }
    } else {
        $response['status'] = false;
        $response['message'] = "Query Execution Failed";
    }
} else {
    $response['status'] = false;
    $response['message'] = "Invalid 'c_id' parameter";
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response); // Encode the response array as JSON and return it
?>
