<?php
require_once('dbconfig.php');

$id = $_POST['id'];
$name = $_POST['name'];
$status = $_POST['status'];
$rate = $_POST['rate'];
$comment = $_POST['comment'];


$response = array();

if (empty($id) || empty($name) || empty($status) || empty($rate) || empty($comment) ) {
    $response['status'] = false;
    $response['message'] = "All fields are required.";
} else {
    // Check if the user already exists by user_id (assuming user_id is a unique identifier)
    $userExistQuery = "SELECT * FROM rating WHERE id = '$id'";
    $userExistResult = mysqli_query($dbconn, $userExistQuery);

    if (mysqli_num_rows($userExistResult) == 0) {
        $insertData = "INSERT INTO rating(id,name,status,rate,comment) 
                       VALUES ('$id', '$name', '$status', '$rate', '$comment')";
        $qry = mysqli_query($dbconn, $insertData);

        if ($qry) {
            $id = mysqli_insert_id($dbconn);
            $response['status'] = true;
            $response['message'] = "Registered Successfully";
            $response['UserId'] = $id;
        } else {
            $response['status'] = false;
            $response['message'] = "Registration Failed";
        }
    } else {
        $response['status'] = false;
        $response['message'] = "User with user_id $id already exists.";
    }
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
