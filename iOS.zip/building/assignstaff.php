<?php
require_once('dbconfig.php');

// Use the correct variable names for each field

$worker_name = $_POST['worker_name'];
$user_name = $_POST['user_name'];
$block = $_POST['block'];
$door = $_POST['door'];
$issue = $_POST['issue'];
$repeated = $_POST['repeated'];
$mob_num = $_POST['mob_num'];
$issues = $_POST['issues'];
$dateofreporting = $_POST['dateofreporting'];
$status = $_POST['status'];

$response = array();

if (  empty($worker_name) || empty($mob_num)) {
    $response['status'] = false;
    $response['message'] = " Worker Name, and Mobile Number are required fields.";
} else {
   
        $insertData = "INSERT INTO issue_details( worker_name, user_name, block, door, issue, repeated, mob_num, issues, dateofreporting, status) 
                       VALUES ( '$worker_name', '$user_name', '$block', '$door', '$issue', '$repeated', '$mob_num', '$issues', '$dateofreporting',  '$status')";
        $qry = mysqli_query($dbconn, $insertData);

        if ($qry) {
            $id = mysqli_insert_id($dbconn);
            $response['status'] = true;
            $response['message'] = "Data inserted successfully";
            $response['Worker Name'] = $worker_name; 
        } else {
            $response['status'] = false;
            $response['message'] = "Failed to insert data: " . mysqli_error($dbconn);
        }
        
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
